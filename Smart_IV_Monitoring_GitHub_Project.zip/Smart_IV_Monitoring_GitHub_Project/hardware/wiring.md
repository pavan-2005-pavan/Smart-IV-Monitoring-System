# Wiring Notes

## HX711 to Arduino Uno
- VCC -> 5V
- GND -> GND
- DOUT/DT -> D3
- SCK/CLK -> D2

## Alert outputs
- Active buzzer signal -> D8, only if current draw is within the board pin rating. Otherwise use a suitable transistor driver and common ground.
- Onboard LED -> D13. An external LED can be used with a 220 ohm series resistor.

## Load cell
Connect the load cell to the HX711 terminals following the labels and datasheet for your exact module. Wire colours vary by manufacturer. Secure the load cell mechanically and ensure the suspended demonstration container cannot fall.

Do not connect this prototype to a patient or clinical IV equipment.
