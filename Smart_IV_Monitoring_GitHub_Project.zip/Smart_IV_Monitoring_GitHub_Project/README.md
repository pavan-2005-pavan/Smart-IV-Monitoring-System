# Smart IV Fluid Monitoring & Alert System

> **Educational prototype only. Not a medical device. Do not use this project to make clinical decisions or to control patient treatment.**

## Project overview
This Arduino prototype estimates the remaining IV-fluid amount by measuring the weight of a suspended demonstration container with a load cell and HX711 amplifier. When the estimated remaining amount falls below a configurable threshold, it activates a buzzer and warning LED.

**Important terminology:** This prototype monitors an IV container's approximate fluid amount. It does **not** measure glucose concentration, blood glucose, or the chemical composition of a fluid. The name “Smart IV Glucose Monitoring” should only be used if a validated glucose sensor is actually part of the project.

## Features
- Load-cell-based weight measurement
- Approximate remaining-fluid estimate
- Configurable low-level alert threshold
- Buzzer and LED alert
- Serial Monitor output for calibration and testing

## Components
- Arduino Uno (or compatible 5 V board)
- Load cell (choose a capacity appropriate for the demonstration container)
- HX711 load-cell amplifier module
- Active buzzer (use a transistor driver if the buzzer current exceeds the Arduino pin rating)
- LED and 220 Ω resistor (optional; onboard LED can be used)
- Jumper wires and breadboard
- Stable mechanical support for the load cell
- Known weights for calibration
- Demonstration container with water (not connected to a patient)

## Wiring (Arduino Uno)
| Module/component | Connection |
|---|---|
| HX711 VCC | Arduino 5V |
| HX711 GND | Arduino GND |
| HX711 DT / DOUT | Arduino D3 |
| HX711 SCK / CLK | Arduino D2 |
| Buzzer signal (+) | Arduino D8 (use a driver if required) |
| Warning LED | Arduino D13 onboard LED, or external LED through 220 Ω |
| Load cell | Connect to HX711 terminals according to the load-cell/HX711 labels and module documentation |

Load-cell wire colours are not universal. Follow the labels/datasheet for your specific load cell and HX711 module.

## Software setup
1. Install the Arduino IDE.
2. Install the **HX711** library by searching for “HX711” in Arduino IDE Library Manager.
3. Open `src/Smart_IV_Fluid_Monitor.ino`.
4. Upload it to the Arduino Uno.
5. Open Serial Monitor at **9600 baud**.
6. Calibrate `CALIBRATION_FACTOR` for your exact load cell and mechanical setup before relying on the displayed estimate.

## Calibration
1. Run the sketch with the load cell mounted securely.
2. With the container removed, tare/zero the scale using the `t` command in Serial Monitor.
3. Place a known test weight on the platform.
4. Adjust `CALIBRATION_FACTOR` until the serial reading matches the known weight. Depending on the library and wiring, the sign may need to be negative.
5. For the fluid estimate, enter the mass of the empty demonstration container in `EMPTY_CONTAINER_MASS_G`.
6. Set `LOW_FLUID_THRESHOLD_ML` to the alert threshold for your demonstration.
7. Re-test with several known masses and verify the buzzer and LED trigger correctly.

The sketch assumes water-like fluid density of approximately 1 g/mL for a classroom demonstration. Real IV fluids and containers can differ; this is not suitable for clinical use.

## How it works
1. The load cell measures the total suspended mass.
2. The HX711 amplifies and digitizes the load-cell signal.
3. The Arduino estimates the fluid mass after subtracting the empty container mass.
4. The mass is converted approximately to millilitres for a water demonstration.
5. If the estimate is at or below the threshold, the LED and buzzer are activated.

## Repository structure
- `src/Smart_IV_Fluid_Monitor.ino` — Arduino sketch
- `hardware/wiring.md` — wiring notes
- `docs/project_report.md` — project report
- `docs/testing_checklist.md` — test checklist
- `docs/circuit_diagram.svg` — illustrative block/wiring diagram

## Safety and limitations
- This is a student learning prototype, not a certified medical device.
- Do not attach it to a patient or use it to make treatment decisions.
- The system estimates container contents by weight; it does not directly measure flow rate, glucose concentration, or whether an IV line is blocked.
- Mechanical mounting, calibration drift, vibration, container movement, and sensor faults can affect readings.
- A real clinical product would require professional medical-device engineering, risk management, verification/validation, electrical safety testing, and applicable regulatory approval.

## Author
Replace this line with your name, department, college, and project team details.
