# Project Report: Smart IV Fluid Monitoring & Alert System

## 1. Introduction
Intravenous (IV) fluids are commonly delivered in healthcare settings. This student prototype demonstrates how a sensor and microcontroller can estimate the amount of fluid remaining in a suspended demonstration container and activate an alert when the estimate reaches a chosen threshold.

## 2. Objective
- Build a low-cost educational model for weight-based fluid-level estimation.
- Read a load cell through an HX711 amplifier.
- Use an Arduino to estimate remaining demonstration fluid.
- Activate an LED and buzzer when the estimated amount is low.

## 3. Components
Arduino Uno, load cell, HX711 amplifier module, active buzzer, LED, resistor, jumper wires, power source, stable support and a water-filled demonstration container.

## 4. Working Principle
The load cell produces a small electrical signal related to the applied load. The HX711 amplifies and digitizes this signal. The Arduino converts the reading into an approximate mass value. After subtracting the measured empty-container mass, the program estimates the remaining fluid volume using a water-density approximation. If the estimate is at or below the programmed threshold, an LED and buzzer alert are activated.

## 5. Block Diagram
Demonstration container → Load cell → HX711 amplifier → Arduino Uno → LED and buzzer alert

## 6. Software
The program is written in Arduino C/C++. The HX711 library is required. The calibration factor and empty-container mass must be measured and adjusted for the actual hardware.

## 7. Testing Plan
1. Confirm the HX711 is detected.
2. Tare the unloaded platform.
3. Test with several known weights.
4. Compare the displayed estimate with the expected mass.
5. Add and remove water from the demonstration container.
6. Confirm the alert turns on at the configured threshold and turns off above it.
7. Repeat tests and record observed errors.

## 8. Expected Outcome
A classroom demonstration that displays an approximate remaining-fluid estimate and activates a local alert when the estimate reaches the set threshold. Actual performance depends on calibration, mechanical stability, and sensor quality.

## 9. Limitations and Safety
This prototype does not measure glucose concentration, blood glucose, IV flow rate, line blockage, or fluid composition. It is not a medical device and must not be used on a patient or to guide treatment. Clinical deployment would require professional engineering, risk analysis, validation, safety testing and applicable regulatory approval.

## 10. Future Improvements
- Add a display for readings.
- Add wireless notification to a test dashboard.
- Add sensor-disconnection and out-of-range detection.
- Improve mechanical mounting and calibration.
- Conduct systematic accuracy and repeatability tests on a non-clinical test rig.

## 11. Conclusion
The project demonstrates the use of a load cell, HX711 amplifier and microcontroller to estimate the amount of fluid in a demonstration container and generate a low-level alert. It is intended for educational prototyping only.
