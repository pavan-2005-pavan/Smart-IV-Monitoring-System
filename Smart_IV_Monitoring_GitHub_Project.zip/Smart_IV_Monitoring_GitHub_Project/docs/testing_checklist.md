# Testing Checklist

Use only a demonstration container with water. Never connect this prototype to a patient.

| Test | Procedure | Expected result | Observed result |
|---|---|---|---|
| Power-up | Power Arduino and HX711 | Board starts; serial status appears | Fill in |
| HX711 connection | Check Serial Monitor | HX711 detected | Fill in |
| Tare | Remove container and send `t` | Reading resets close to zero | Fill in |
| Calibration | Add a known test weight | Reading is close to known mass after calibration | Fill in |
| Normal level | Use a mass above the set threshold | LED/buzzer off | Fill in |
| Low level | Reduce demonstration water until threshold is crossed | LED/buzzer alert on | Fill in |
| Recovery | Add water back above threshold | Alert turns off | Fill in |
| Repeatability | Repeat each test several times | Similar readings under stable conditions | Fill in |

Record actual values and errors rather than claiming results that have not been measured.
