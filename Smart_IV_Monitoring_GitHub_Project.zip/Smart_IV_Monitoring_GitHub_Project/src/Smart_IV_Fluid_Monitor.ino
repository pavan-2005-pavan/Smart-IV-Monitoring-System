/*
  Smart IV Fluid Monitoring & Alert System
  Educational prototype only - NOT for clinical use.

  Hardware:
    Arduino Uno
    Load cell + HX711 amplifier
    HX711 DOUT -> D3
    HX711 SCK  -> D2
    Active buzzer signal -> D8 (use a driver if needed)
    Onboard LED -> D13

  Install the "HX711" library using Arduino IDE Library Manager.
  Calibrate CALIBRATION_FACTOR for your specific hardware.
*/

#include "HX711.h"

const byte HX711_DOUT_PIN = 3;
const byte HX711_SCK_PIN  = 2;
const byte BUZZER_PIN     = 8;
const byte LED_PIN        = 13;

HX711 scale;

// IMPORTANT: Calibrate this value for your exact load cell and mounting.
// The value below is only a starting placeholder and will likely need adjustment.
float CALIBRATION_FACTOR =  -7050.0;

// Set the empty demonstration container mass in grams.
// Measure your own empty container and update this value.
const float EMPTY_CONTAINER_MASS_G = 35.0;

// Demonstration alert threshold. Adjust for your model.
const float LOW_FLUID_THRESHOLD_ML = 100.0;

// For a water demonstration, 1 g is approximately 1 mL.
// This approximation is not suitable for clinical measurements.
const float DEMO_DENSITY_G_PER_ML = 1.0;

unsigned long lastPrintMs = 0;
const unsigned long PRINT_INTERVAL_MS = 1000;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  scale.begin(HX711_DOUT_PIN, HX711_SCK_PIN);
  scale.set_scale(CALIBRATION_FACTOR);

  Serial.println(F("\nSmart IV Fluid Monitoring - Educational Prototype"));
  Serial.println(F("NOT A MEDICAL DEVICE. Do not use on a patient."));
  Serial.println(F("Commands: t = tare/zero; h = show help"));
  Serial.println(F("Allow the load cell to settle before taking readings."));

  if (!scale.is_ready()) {
    Serial.println(F("ERROR: HX711 not detected. Check power and wiring."));
  } else {
    Serial.println(F("HX711 detected. Tare with the empty platform using command 't'."));
  }
}

void loop() {
  if (Serial.available()) {
    char command = Serial.read();
    if (command == 't' || command == 'T') {
      Serial.println(F("Taring scale... remove the container and keep the platform still."));
      scale.tare(20);
      Serial.println(F("Tare complete."));
    } else if (command == 'h' || command == 'H') {
      Serial.println(F("Commands: t = tare/zero; h = help"));
    }
  }

  if (millis() - lastPrintMs >= PRINT_INTERVAL_MS) {
    lastPrintMs = millis();

    if (!scale.is_ready()) {
      Serial.println(F("ERROR: HX711 not ready; check connections."));
      setAlert(false);
      return;
    }

    // Average several readings to reduce noise.
    float totalMassG = scale.get_units(5);
    if (totalMassG < 0) totalMassG = 0;

    float fluidMassG = totalMassG - EMPTY_CONTAINER_MASS_G;
    if (fluidMassG < 0) fluidMassG = 0;

    float estimatedFluidMl = fluidMassG / DEMO_DENSITY_G_PER_ML;

    Serial.print(F("Total mass: "));
    Serial.print(totalMassG, 1);
    Serial.print(F(" g | Estimated fluid: "));
    Serial.print(estimatedFluidMl, 1);
    Serial.print(F(" mL | Status: "));

    bool lowFluid = estimatedFluidMl <= LOW_FLUID_THRESHOLD_ML;
    if (lowFluid) {
      Serial.println(F("LOW LEVEL ALERT"));
    } else {
      Serial.println(F("NORMAL (prototype estimate)"));
    }
    setAlert(lowFluid);
  }
}

void setAlert(bool active) {
  digitalWrite(LED_PIN, active ? HIGH : LOW);
  // Intermittent beeps make the alert noticeable in a classroom demo.
  if (active) {
    static unsigned long lastBeepMs = 0;
    static bool buzzerState = false;
    if (millis() - lastBeepMs >= 250) {
      lastBeepMs = millis();
      buzzerState = !buzzerState;
      digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);
    }
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }
}
